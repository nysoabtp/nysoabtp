// ══════════════════════════════════════════════════════════════
// NYSOA BTP — modules_new.js (avec fallback localStorage)
// ══════════════════════════════════════════════════════════════

// Helpers localStorage
const LS = {
    get(k) { try { return JSON.parse(localStorage.getItem('nysoa_' + k) || '[]') } catch { return [] } },
    set(k, v) { localStorage.setItem('nysoa_' + k, JSON.stringify(v)) }
};

function fmt(n) {
    if (n === null || n === undefined || n === '') return '—';
    return Number(n).toLocaleString('fr-FR') + ' Ar';
}
function fmtDate(d) {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('fr-FR');
}

async function tryDB(fn, lsKey) {
    try { return await fn(); }
    catch (e) {
        if (lsKey) return LS.get(lsKey);
        throw e;
    }
}
// ── Bannière de synchro en attente ───────────────────────────
const PENDING_KEYS_STORAGE = 'nysoa_pending_sync_keys';

function markPendingSync(lsKey) {
    const keys = JSON.parse(localStorage.getItem(PENDING_KEYS_STORAGE) || '[]');
    if (!keys.includes(lsKey)) keys.push(lsKey);
    localStorage.setItem(PENDING_KEYS_STORAGE, JSON.stringify(keys));
    showSyncBanner();
}

function clearPendingSync(lsKey) {
    const keys = JSON.parse(localStorage.getItem(PENDING_KEYS_STORAGE) || '[]').filter(k => k !== lsKey);
    localStorage.setItem(PENDING_KEYS_STORAGE, JSON.stringify(keys));
    if (!keys.length) hideSyncBanner();
}

function showSyncBanner() {
    let banner = document.getElementById('nysoa-sync-banner');
    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'nysoa-sync-banner';
        banner.style.cssText = 'position:fixed;bottom:16px;left:50%;transform:translateX(-50%);background:#856404;color:#fff;padding:10px 20px;border-radius:8px;font-size:13px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,.3);display:flex;align-items:center;gap:10px;';
        banner.innerHTML = '<i class="fas fa-exclamation-triangle"></i> <span>Données sauvegardées localement — sera synchronisé à la reconnexion</span><button onclick="document.getElementById(\'nysoa-sync-banner\').style.display=\'none\'" style="background:none;border:none;color:#fff;cursor:pointer;font-size:16px;padding:0 4px">×</button>';
        document.body.appendChild(banner);
    }
    banner.style.display = 'flex';
}

function hideSyncBanner() {
    const banner = document.getElementById('nysoa-sync-banner');
    if (banner) banner.style.display = 'none';
}

// Afficher la bannière au chargement si des données sont en attente
document.addEventListener('DOMContentLoaded', () => {
    const pending = JSON.parse(localStorage.getItem(PENDING_KEYS_STORAGE) || '[]');
    if (pending.length) showSyncBanner();
});

async function trySave(table, data, lsKey) {
    try {
        const { error } = await db.from(table).insert(Array.isArray(data) ? data : [data]);
        if (error) throw error;
        clearPendingSync(lsKey);
    } catch (e) {
        const items = LS.get(lsKey);
        const entry = { id: Date.now(), ...data, _pending: true };
        items.push(entry);
        LS.set(lsKey, items);
        markPendingSync(lsKey);
    }
}
async function tryUpdate(table, id, data, lsKey) {
    try {
        const { error } = await db.from(table).update(data).eq('id', id);
        if (error) throw error;
    } catch (e) {
        const items = LS.get(lsKey);
        const idx = items.findIndex(i => i.id === id);
        if (idx >= 0) { items[idx] = { ...items[idx], ...data }; LS.set(lsKey, items); }
    }
}
async function tryDelete(table, id, lsKey) {
    try {
        const { error } = await db.from(table).delete().eq('id', id);
        if (error) throw error;
    } catch (e) {
        const items = LS.get(lsKey).filter(i => i.id !== id);
        LS.set(lsKey, items);
    }
}

// ══ MODULE 1 — ANTOKA ════════════════════════════════════════
async function loadAntoka() {
    const el = document.getElementById('antoka-tbody');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="13" style="text-align:center;padding:30px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i> Chargement...</td></tr>';
    try {
        let rows;
        try { const { data } = await db.from('antoka').select('*').order('employe'); if (data) rows = data; else throw 404; }
        catch (e) { rows = LS.get('antoka'); }
        rows = rows || [];
        const totalDepart = rows.reduce((s,r)=>s+(r.montant_depart||0),0);
        const totalPaye   = rows.reduce((s,r)=>s+(r.montant_paye||0),0);
        const totalReste  = rows.reduce((s,r)=>s+(r.reste||0),0);
        document.getElementById('antoka-total-depart') && (document.getElementById('antoka-total-depart').textContent = fmt(totalDepart));
        document.getElementById('antoka-total-paye')   && (document.getElementById('antoka-total-paye').textContent   = fmt(totalPaye));
        document.getElementById('antoka-total-reste')  && (document.getElementById('antoka-total-reste').textContent  = fmt(totalReste));
        if (!rows.length) { el.innerHTML = '<tr><td colspan="13" style="text-align:center;padding:30px;color:var(--text-muted)">Aucun antoka enregistré</td></tr>'; return; }
        el.innerHTML = rows.map(r => {
            const pct = r.montant_depart ? Math.round((r.montant_paye||0)/r.montant_depart*100) : 0;
            const color = pct===100 ? 'var(--green)' : pct>50 ? 'var(--orange)' : 'var(--red)';
            return `<tr>
                <td style="font-weight:600">${r.employe||'—'}</td>
                <td>${r.chantier||'—'}</td>
                <td style="font-family:monospace">${fmt(r.montant_depart)}</td>
                <td style="color:var(--green);font-family:monospace">${fmt(r.montant_paye)}</td>
                <td style="color:${r.reste>0?'var(--red)':'var(--green)'};font-weight:600;font-family:monospace">${fmt(r.reste)}</td>
                <td style="font-family:monospace">${fmt(r.tranche1)}</td>
                <td>${fmtDate(r.date_tranche1)}</td>
                <td style="font-family:monospace">${fmt(r.tranche2)}</td>
                <td>${fmtDate(r.date_tranche2)}</td>
                <td style="font-family:monospace">${fmt(r.tranche3)}</td>
                <td>${fmtDate(r.date_tranche3)}</td>
                <td>
                    <div style="display:flex;align-items:center;gap:8px">
                        <div style="flex:1;height:6px;background:var(--border);border-radius:10px;overflow:hidden">
                            <div style="width:${pct}%;height:100%;background:${color};border-radius:10px"></div>
                        </div>
                        <span style="font-size:0.75rem;color:var(--text-muted);min-width:30px">${pct}%</span>
                    </div>
                </td>
                <td>
                    <button class="btn-icon" title="Ajouter paiement" onclick="openAntokaPayment(${r.id},'${(r.employe||'').replace(/'/g,"\\'")}',${r.reste||0})"><i class="fas fa-plus"></i></button>
                    <button class="btn-icon" title="Supprimer" onclick="deleteAntoka(${r.id})" style="color:var(--red)"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        }).join('');
    } catch(e) {
        el.innerHTML = `<tr><td colspan="13" style="text-align:center;padding:30px;color:var(--red)">${e.message}</td></tr>`;
    }
}

function openAntokaPayment(id, employe, reste) {
    document.getElementById('ap-id').value = id;
    document.getElementById('ap-employe').textContent = employe;
    document.getElementById('ap-reste').textContent = fmt(reste);
    document.getElementById('ap-montant').value = '';
    openModal('modal-antoka-payment');
}

async function saveAntokaPayment() {
    const id     = document.getElementById('ap-id').value;
    const montant = parseFloat(document.getElementById('ap-montant').value)||0;
    const date    = document.getElementById('ap-date').value;
    if (!montant || !date) { alert('Remplissez montant et date'); return; }
    try {
        let row;
        try { const { data } = await db.from('antoka').select('montant_paye,montant_depart').eq('id',id).single(); row = data; }
        catch (e) { row = LS.get('antoka').find(i => i.id == id); }
        const newPaye  = (row.montant_paye||0) + montant;
        const newReste = (row.montant_depart||0) - newPaye;
        await tryUpdate('antoka', id, { montant_paye: newPaye, reste: Math.max(0,newReste), date }, 'antoka');
        closeModal('modal-antoka-payment');
        loadAntoka();
        showNotification('Paiement antoka enregistré ✓', 'success');
    } catch(e) { alert(e.message); }
}

async function saveAntoka(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const depart = parseFloat(fd.get('montant_depart'))||0;
    const paye   = parseFloat(fd.get('montant_paye'))||0;
    const t1 = parseFloat(fd.get('tranche1'))||0;
    const t2 = parseFloat(fd.get('tranche2'))||0;
    const t3 = parseFloat(fd.get('tranche3'))||0;
    const obj = {
        employe: fd.get('employe'), chantier: fd.get('chantier'),
        montant_depart: depart, montant_paye: paye,
        reste: Math.max(0, depart - paye), date: fd.get('date'), motif: fd.get('motif'),
        tranche1: t1, date_tranche1: fd.get('date_tranche1')||null,
        tranche2: t2, date_tranche2: fd.get('date_tranche2')||null,
        tranche3: t3, date_tranche3: fd.get('date_tranche3')||null
    };
    await trySave('antoka', obj, 'antoka');
    closeModal('modal-antoka');
    e.target.reset();
    loadAntoka();
    showNotification('Antoka ajouté ✓', 'success');
}

async function deleteAntoka(id) {
    if (!confirm('Supprimer cet antoka ?')) return;
    await tryDelete('antoka', id, 'antoka');
    loadAntoka();
    showNotification('Supprimé', 'success');
}

// ══ MODULE 2 — CRÉDIT FOURNISSEURS ══════════════════════════
async function loadCredits() {
    const el = document.getElementById('credits-tbody');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:30px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i></td></tr>';
    try {
        let rows;
        try { const { data } = await db.from('credits_fournisseurs').select('*').order('fournisseur'); if (data) rows = data; else throw 404; }
        catch (e) { rows = LS.get('credits'); }
        rows = rows || [];
        const totalDette = rows.reduce((s,r)=>s+(r.montant_total||0),0);
        const totalReste = rows.reduce((s,r)=>s+(r.reste1||0)+(r.reste2||0)+(r.reste3||0),0);
        document.getElementById('credit-total-dette') && (document.getElementById('credit-total-dette').textContent = fmt(totalDette));
        document.getElementById('credit-total-reste') && (document.getElementById('credit-total-reste').textContent = fmt(totalReste));
        if (!rows.length) { el.innerHTML = '<tr><td colspan="11" style="text-align:center;padding:30px">Aucun crédit enregistré</td></tr>'; return; }
        el.innerHTML = rows.map(r => {
            const totalPayé = (r.montant1||0)+(r.montant2||0)+(r.montant3||0);
            const resteTotal = (r.montant_total||0) - totalPayé;
            return `<tr>
                <td style="font-weight:600">${r.fournisseur}</td>
                <td style="font-family:monospace">${fmt(r.montant_total)}</td>
                <td style="color:var(--green);font-family:monospace">${fmt(totalPayé)}</td>
                <td style="color:${resteTotal>0?'var(--red)':'var(--green)'};font-weight:600;font-family:monospace">${fmt(resteTotal)}</td>
                <td>${fmtDate(r.date1)||'—'}</td>
                <td style="font-family:monospace">${fmt(r.montant1)}</td>
                <td>${fmtDate(r.date2)||'—'}</td>
                <td style="font-family:monospace">${fmt(r.montant2)}</td>
                <td>${fmtDate(r.date3)||'—'}</td>
                <td style="font-family:monospace">${fmt(r.montant3)}</td>
                <td>
                    <button class="btn-icon" title="Ajouter échéance" onclick="openCreditPayment(${r.id})"><i class="fas fa-plus"></i></button>
                    <button class="btn-icon" title="Supprimer" onclick="deleteCredit(${r.id})" style="color:var(--red)"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        }).join('');
    } catch(e) { el.innerHTML = `<tr><td colspan="11" style="color:var(--red);padding:20px">${e.message}</td></tr>`; }
}

async function saveCredit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const mt = parseFloat(fd.get('montant_total'))||0;
    const m1 = parseFloat(fd.get('montant1'))||0;
    const m2 = parseFloat(fd.get('montant2'))||0;
    const m3 = parseFloat(fd.get('montant3'))||0;
    const obj = {
        fournisseur: fd.get('fournisseur'), montant_total: mt,
        date1: fd.get('date1')||null, montant1: m1, reste1: mt - m1,
        date2: fd.get('date2')||null, montant2: m2, reste2: Math.max(0, mt - m1 - m2),
        date3: fd.get('date3')||null, montant3: m3, reste3: Math.max(0, mt - m1 - m2 - m3)
    };
    await trySave('credits_fournisseurs', obj, 'credits');
    closeModal('modal-credit');
    e.target.reset(); loadCredits();
    showNotification('Crédit fournisseur ajouté ✓', 'success');
}

async function deleteCredit(id) {
    if (!confirm('Supprimer ?')) return;
    await tryDelete('credits_fournisseurs', id, 'credits');
    loadCredits(); showNotification('Supprimé', 'success');
}

// ══ MODULE 3 — CAISSE ═══════════════════════════════════════
async function loadCaisse() {
    const el = document.getElementById('caisse-tbody');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i></td></tr>';
    try {
        let rows;
        try { const { data } = await db.from('caisse').select('*').order('date',{ascending:false}).limit(200); if (data) rows = data; else throw 404; }
        catch (e) { rows = LS.get('caisse').sort((a,b)=>new Date(b.date)-new Date(a.date)); }
        rows = rows || [];
        const soldeActuel = rows.length ? (rows[0].solde_fin||0) : 0;
        const totalEntrees = rows.filter(r=>(r.solde_fin||0)>(r.solde_debut||0)).reduce((s,r)=>s+(r.montant||0),0);
        const totalSorties = rows.filter(r=>(r.solde_fin||0)<(r.solde_debut||0)).reduce((s,r)=>s+(r.montant||0),0);
        document.getElementById('caisse-solde')   && (document.getElementById('caisse-solde').textContent   = fmt(soldeActuel));
        document.getElementById('caisse-entrees') && (document.getElementById('caisse-entrees').textContent = fmt(totalEntrees));
        document.getElementById('caisse-sorties') && (document.getElementById('caisse-sorties').textContent = fmt(totalSorties));
        document.getElementById('caisse-nb')      && (document.getElementById('caisse-nb').textContent      = rows.length);
        if (!rows.length) { el.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px">Caisse vide</td></tr>'; return; }
        el.innerHTML = rows.map(r => {
            const type = (r.solde_fin||0) > (r.solde_debut||0) ? 'entree' : 'sortie';
            const color = type === 'entree' ? 'var(--green)' : 'var(--red)';
            const sign  = type === 'entree' ? '+' : '-';
            return `<tr>
            <td>${fmtDate(r.date)}</td>
            <td>${r.designation||'—'}</td>
            <td style="color:${color};font-family:monospace">${sign}${fmt(r.montant)}</td>
            <td style="font-family:monospace;font-weight:600">${fmt(r.solde_fin)}</td>
            <td><button class="btn-icon" onclick="deleteCaisse(${r.id})" style="color:var(--red)"><i class="fas fa-trash"></i></button></td>
        </tr>`;}).join('');
    } catch(e) { el.innerHTML = `<tr><td colspan="5" style="color:var(--red);padding:20px">${e.message}</td></tr>`; }
}

function ouvrirModalCaisse(type) {
    document.getElementById('caisse-type-input').value = type;
    const title = document.getElementById('modal-caisse-title');
    if (title) title.textContent = type === 'entree' ? 'Entrée de caisse' : 'Sortie de caisse';
    openModal('modal-caisse');
}

async function saveCaisse(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const montant = parseFloat(fd.get('montant'))||0;
    const type = fd.get('type') || 'sortie';
    try {
        let last;
        try { const { data } = await db.from('caisse').select('solde_fin').order('date',{ascending:false}).limit(1); last = data; }
        catch (e) { last = LS.get('caisse').sort((a,b)=>new Date(b.date)-new Date(a.date)); }
        const soldeDebut = last && last.length ? (last[0].solde_fin||0) : 0;
        const soldeFin   = type === 'entree' ? soldeDebut + montant : Math.max(0, soldeDebut - montant);
        const obj = { date: fd.get('date'), designation: fd.get('designation'), montant, solde_debut: soldeDebut, solde_fin: soldeFin };
        await trySave('caisse', obj, 'caisse');
        closeModal('modal-caisse');
        e.target.reset(); loadCaisse();
        showNotification('Mouvement caisse ajouté ✓', 'success');
    } catch(e) { alert(e.message); }
}

async function deleteCaisse(id) {
    if (!confirm('Supprimer ce mouvement ?')) return;
    await tryDelete('caisse', id, 'caisse');
    loadCaisse(); showNotification('Supprimé', 'success');
}

// ══ MODULE 4 — CATALOGUE PRIX ══════════════════════════════
async function loadCatalogue() {
    const el = document.getElementById('catalogue-tbody');
    if (!el) return;
    const search = (document.getElementById('catalogue-search')||{}).value||'';
    const fourn  = (document.getElementById('catalogue-fourn')||{}).value||'';
    el.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i></td></tr>';
    try {
        let rows;
        try {
            let q = db.from('catalogue_prix').select('*').order('designation');
            if (search) q = q.ilike('designation', `%${search}%`);
            if (fourn)  q = q.eq('fournisseur', fourn);
            const { data } = await q; if (data) rows = data; else throw 404;
        }
        catch (e) {
            rows = LS.get('catalogue');
            if (search) rows = rows.filter(r => (r.designation||'').toLowerCase().includes(search.toLowerCase()));
            if (fourn) rows = rows.filter(r => r.fournisseur === fourn);
        }
        rows = rows || [];
        document.getElementById('catalogue-count') && (document.getElementById('catalogue-count').textContent = rows.length + ' articles');
        if (!rows.length) { el.innerHTML = '<tr><td colspan="5" style="text-align:center;padding:30px">Aucun article trouvé</td></tr>'; return; }
        el.innerHTML = rows.map(r => `<tr>
            <td style="font-weight:500">${r.designation||'—'}</td>
            <td style="font-family:monospace;color:var(--blue);font-weight:600">${fmt(r.prix_unitaire)}</td>
            <td>${r.unite||'—'}</td>
            <td><span style="background:var(--blue-bg);color:var(--blue);padding:2px 8px;border-radius:20px;font-size:0.75rem;font-weight:600">${r.fournisseur||'—'}</span></td>
            <td>
                <button class="btn-icon" title="Utiliser dans commande" onclick="usePrix('${(r.designation||'').replace(/'/g,"\\'")}',${r.prix_unitaire||0})"><i class="fas fa-cart-plus"></i></button>
                <button class="btn-icon" title="Supprimer" onclick="deletePrix(${r.id})" style="color:var(--red)"><i class="fas fa-trash"></i></button>
            </td>
        </tr>`).join('');
    } catch(e) { el.innerHTML = `<tr><td colspan="5" style="color:var(--red);padding:20px">${e.message}</td></tr>`; }
}

function usePrix(designation, pu) {
    showNotification(`${designation} — ${pu.toLocaleString('fr-FR')} Ar copié`, 'info');
}

async function savePrix(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const obj = { designation: fd.get('designation'), prix_unitaire: parseFloat(fd.get('prix_unitaire'))||0, unite: fd.get('unite'), fournisseur: fd.get('fournisseur') };
    await trySave('catalogue_prix', obj, 'catalogue');
    closeModal('modal-prix');
    e.target.reset(); loadCatalogue();
    showNotification('Article ajouté au catalogue ✓', 'success');
}

async function deletePrix(id) {
    if (!confirm('Supprimer cet article du catalogue ?')) return;
    await tryDelete('catalogue_prix', id, 'catalogue');
    loadCatalogue(); showNotification('Supprimé', 'success');
}

// ══ MODULE 5 — CONTRATS PRESTATAIRES ════════════════════════
async function loadContrats() {
    const el = document.getElementById('contrats-tbody');
    if (!el) return;
    el.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:30px;color:var(--text-muted)"><i class="fas fa-spinner fa-spin"></i></td></tr>';
    try {
        let rows;
        try { const { data } = await db.from('contrats').select('*').order('created_at',{ascending:false}); if (data) rows = data; else throw 404; }
        catch (e) { rows = LS.get('contrats_prestataires'); }
        rows = rows || [];
        document.getElementById('contrats-count') && (document.getElementById('contrats-count').textContent = rows.filter(r=>r.statut==='EN COURS').length + ' en cours');
        if (!rows.length) { el.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:30px">Aucun contrat</td></tr>'; return; }
        el.innerHTML = rows.map(r => {
            const statusColor = r.statut==='EN COURS' ? 'var(--green)' : r.statut==='TERMINE' ? 'var(--blue)' : 'var(--orange)';
            const statusBg    = r.statut==='EN COURS' ? 'var(--green-bg)' : r.statut==='TERMINE' ? 'var(--blue-bg)' : 'var(--orange-bg)';
            return `<tr>
                <td style="font-weight:600">${r.designation||'—'}</td>
                <td>${r.prestataire||'—'}</td>
                <td>${r.chantier||'—'}</td>
                <td style="font-family:monospace">${r.prix_convenu||'—'}</td>
                <td>${fmtDate(r.date_debut)}</td>
                <td><span style="background:${statusBg};color:${statusColor};padding:3px 10px;border-radius:20px;font-size:0.75rem;font-weight:600">${r.statut}</span></td>
                <td>
                    <button class="btn-icon" title="Terminer" onclick="cloturerContrat(${r.id})"><i class="fas fa-check"></i></button>
                    <button class="btn-icon" title="Supprimer" onclick="deleteContrat(${r.id})" style="color:var(--red)"><i class="fas fa-trash"></i></button>
                </td>
            </tr>`;
        }).join('');
    } catch(e) { el.innerHTML = `<tr><td colspan="7" style="color:var(--red);padding:20px">${e.message}</td></tr>`; }
}

async function saveContrat(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const obj = {
        designation: fd.get('designation'), prestataire: fd.get('prestataire'),
        chantier: fd.get('chantier'), prix_convenu: fd.get('prix_convenu'),
        date_debut: fd.get('date_debut')||null, date_fin_prevue: fd.get('date_fin_prevue')||null,
        statut: 'EN COURS'
    };
    await trySave('contrats', obj, 'contrats_prestataires');
    closeModal('modal-contrat');
    e.target.reset(); loadContrats();
    showNotification('Contrat ajouté ✓', 'success');
}

async function cloturerContrat(id) {
    if (!confirm('Marquer ce contrat comme terminé ?')) return;
    const today = new Date().toISOString().split('T')[0];
    await tryUpdate('contrats', id, { statut:'TERMINE', date_fin: today }, 'contrats_prestataires');
    loadContrats(); showNotification('Contrat clôturé ✓', 'success');
}

async function deleteContrat(id) {
    if (!confirm('Supprimer ce contrat ?')) return;
    await tryDelete('contrats', id, 'contrats_prestataires');
    loadContrats(); showNotification('Supprimé', 'success');
}

// ══ INIT — fermer modals en cliquant dehors ══════════════════
document.addEventListener('DOMContentLoaded', () => {
    ['modal-antoka','modal-antoka-payment','modal-credit','modal-caisse','modal-prix','modal-contrat'].forEach(id => {
        const m = document.getElementById(id);
        if (m) m.addEventListener('click', e => { if(e.target === m) closeModal(id); });
    });
});
